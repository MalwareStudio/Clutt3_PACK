Clutt3 Virus
----------------------------------------
Author: Clutter Tech
My youtube channel: https://www.youtube.com/channel/UC9keh4wDjXFyiRhHDE_h90Q
File type: exe
Malware type: Trojan.Win32
OS support: win7/win8/win8.1/win10
Programming language: C#
Version: 3.0
Old versions: Clutter Destructive, Clutt
----------------------------------------
Please be careful! This virus is for 
entertainment only. DO NOT RUN ON A 
REAL MACHINE !!!
----------------------------------------


